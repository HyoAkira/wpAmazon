Lisans Adı: wpAmazon Özel Lisansı

Umut Can Akçay ("Lisans Sahibi"), burada wpAmazon eklentisini ("Yazılım") sunar ve aşağıdaki lisans koşulları altında kullanımınıza izin verir:

1. Çoğaltma:
   a. Yazılımı bionluk üzerinden iletişime benimle iletşime geçip satın aldıktan sonra kopyalarını çoğaltabilir ve bunları kişisel veya ticari amaçlarla kullanabilirsiniz. Ancak, her kullanımda, bu lisans metnini ve tüm telif hakkı bildirimlerini korumanız gerekmektedir. Modifiye ederek veya etmeyerek herhangi bir şekilde dağıtmanız yasaktır.

2. Değişiklikler:
   a. Yazılımda herhangi bir değişiklik yapma yetkisi yalnızca Lisans Sahibi'ne aittir. Yazılımın kaynak kodunu değiştirmek, düzenlemek veya başka bir şekilde modifiye etmek yasaktır.

3. Telif Hakkı Bildirimleri:
   a. Yazılımın tüm kopyalarında, telif hakkı bildirimleri, yazar adı (Umut Can Akçay) ve yazar URL'si (https://bionluk.com/umutcan157) kaldırılamaz veya değiştirilemez.

4. Sorumluluk Reddi:
   a. Yazılım, "olduğu gibi" sağlanır ve herhangi bir garanti olmaksızın kullanılır. Lisans Sahibi, Yazılımın kullanımı veya kullanılamaması sonucu doğrudan veya dolaylı olarak ortaya çıkan hiçbir zarardan sorumlu tutulamaz.

5. Uygulanabilirlik:
   a. Bu lisans metni, Yazılımın tüm kullanıcıları için geçerlidir ve her bir kullanıcı bu koşulları kabul eder. Bu lisansın hükümleri, ilgili yerel yasalara aykırıysa, sizde bulunan bütün kopyaların imha edilmesi gerekmektedir.

6. Lisansın Sonlandırılması:
   a. Bu lisans, herhangi bir kullanıcının bu koşulları ihlal etmesi durumunda sona erdirilebilir. Bu durumda, tüm kopyaların imha edilmesi gerekmektedir.

Bu özel lisans, Umut Can Akçay'ın wpAmazon yazılımı üzerindeki haklarını korumayı amaçlamaktadır. Bu lisans, diğer lisanslarla çelişiyorsa, bu özel lisans önceliklidir.

