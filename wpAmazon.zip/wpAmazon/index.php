<?php
/*
Plugin Name:  Umut Can Akçay | wpAmazon
Plugin URI:   https://bionluk.com/umutcan157
Description:  A plugin about getting amazon product info
Version:      1.0
Author:       Umut Can Akçay 
Author URI:   https://bionluk.com/umutcan157
License:      Custom License
License URI:  /licence.md
 
*/

function wpamazon_add_menu() {
    add_menu_page(
        'wpAmazon', // Menü adı
        'wpAmazon', // Menü görüntüsü
        'manage_options', // Gerekli yetki düzeyi
        'wpamazon-settings', // Menü slug
        'wpamazon_settings_page', // Menü sayfasının içeriğini oluşturan işlev
        'dashicons-cart' // Menü simgesi
    );
}
add_action('admin_menu', 'wpamazon_add_menu');
function wpamazon_enqueue_styles() {
    wp_enqueue_style('tailwind', 'https://cdn.tailwindcss.com');
}
add_action('admin_enqueue_scripts', 'wpamazon_enqueue_styles');
// Eklenti menü sayfasının içeriği
function wpamazon_settings_page() {
    // Burada menü sayfasının içeriğini oluşturabilirsiniz
    ?>
   <link href="https://cdn.jsdelivr.net/npm/daisyui@3.2.1/dist/full.css" rel="stylesheet" type="text/css" />
   <script src="https://cdn.tailwindcss.com"></script>
<h1 class="font-semibold text-xl">wpAmazon - Umut Can Akçay</h1>
<p class="text-indigo-800">Bu eklenti shortcode'lara göre ayarlanmıştır. Elementor & Divi gibi builderlar ile kolayca kullanılabilir.</p>
<p><b>Örnek kullanım:</b><br>
[wpamazon mode="title" code="B09NMS4H9K"]<br>
[wpamazon mode="price" code="B09NMS4H9K"]
</p>
    <?php
}

function getProductTitlenPrice($code,$parameter1='<span class="a-price-whole">',$parameter1end='<span class="a-price-decimal">',$parameter2='<span id="productTitle" class="a-size-large product-title-word-break">',$parameter2end="</span>"){
    $cache_key = 'product_' . $code;
    // $fgc = file_get_contents("https://amazon.com/dp/".$code);
    $fgc = wp_cache_get($cache_key, 'product_data'); // Önbellekten içeriği al
if($fgc == false){
    $fgcx = wp_remote_get("https://amazon.com/dp/".$code,stream_context_create([
        'ssl' => [
            'allow_self_signed'=> true
        ]
    ]));
    $fgc = wp_remote_retrieve_body( $fgcx );
    wp_cache_set($cache_key, $fgc, 'product_data', 3600);
}

$parcalaprice = explode($parameter1,$fgc);
$price = explode($parameter1end,$parcalaprice[1])[0] ;



    $parcalaTitle = explode($parameter2, $fgc);
    $parcala2Title = explode($parameter2end, $parcalaTitle[1]);
    $title = $parcala2Title[0];

    return ["title"=>$title,"price"=>$price];
}

// wpamazon shortcode'unu oluştur
function wpamazon_shortcode($atts) {


    $productCode = $atts["code"];
    $product = getProductTitlenPrice($productCode);
    switch($atts["mode"]){
        case "price": {
return $product["price"];
            break;
        }
        case "title": {
            return $product["title"];
                        break;
                    }
    }

   
}
add_shortcode('wpamazon', 'wpamazon_shortcode');

?>